How to run the exported model.
Please run the executable file (<modelname>.bat for Windows or <modelname>.sh for Mac and Linux) located in the same folder.